import java.net.*;
import java.util.Arrays;
import java.util.stream.IntStream;
import java.io.*;

public class DnsClient {
	static int timeout = 3;
	static int retries = 3;
	static int port = 53;
	static String queryFlag = "A";
	static byte[] serverIP = new byte[4];
	static String serverIPString = "";
	static String name = "";

	public static void main(String[] args) throws Exception {
		System.out.println();
		DnsClient client = new DnsClient();
		client.DNSClientHandler(args);
		System.out.println();
	}

	public void DNSClientHandler(String args[]) throws Exception {

		// 1- parse input args to get values for all above instance vars

		parseInput(args);
		// 2- pass relevant vals to some sort of request builder method
		RequestPacket currPacket = new RequestPacket(name, queryFlag);
		byte[] requestPacket = currPacket.genRequestPacket();
		byte[] responsePacket = new byte[1024];
		// 3- make socket and send the request
		int numRetries = 0;
		double startTime;
		double endTime;

		System.out.println("DnsClient sending request for " + name);
		System.out.println("Server: " + serverIPString);
		System.out.println("Request type: " + queryFlag);
		while (numRetries < retries) {
			try {
				DatagramSocket clientSocket = new DatagramSocket();
				clientSocket.setSoTimeout(timeout * 1000);
				InetAddress ipAddress = InetAddress.getByAddress(serverIP);

				DatagramPacket request = new DatagramPacket(requestPacket, requestPacket.length, ipAddress, 53);
				DatagramPacket response = new DatagramPacket(responsePacket, responsePacket.length);

				startTime = System.currentTimeMillis();
				clientSocket.send(request);
				clientSocket.receive(response);
				int zeroCounter = 0;
				for (int i = 0; i < 20; i++) {
					if (responsePacket[i] == (byte) 0)
						zeroCounter++;
				}
				endTime = System.currentTimeMillis();
				if (zeroCounter < 20) {
					double timeTaken = ((endTime - startTime) / 1000.0);
					System.out.println(
							"Response received after " + timeTaken + " seconds and " + numRetries + " retries");
					System.out.println();
					ResponsePacket DnsResponse = new ResponsePacket(responsePacket, requestPacket.length, queryFlag,
							name);
					break;
				}
				numRetries++;
			} catch (SocketTimeoutException s) {
				System.out.println("ERROR\tThe Socket Timed Out");
				if (numRetries < retries) {
					System.out.println("Retry " + (numRetries + 1));
					numRetries++;
				}
			}
		}

		if (numRetries >= retries)
			System.out.println("ERROR\tRetry Limit Reached");

	}

	private static void parseInput(String[] input) {
		boolean serverFlag = false;
		boolean nameFlag = false;
		for (int i = 0; i < input.length; i++) {
			switch (input[i]) {
				case "-t":
					try {
						timeout = Integer.parseInt(input[i + 1]);
						i += 1;
					} catch (Exception e) {
						System.out.println("ERROR\tMissing timeout duration value!");
						System.out.println("ERROR\tRewrite input correctly.");
						return;
					}
					break;
				case "-r":
					try {
						retries = Integer.parseInt(input[i + 1]);
						i += 1;
					} catch (Exception e) {
						System.out.println("ERROR\tMissing number of retries!");
						System.out.println("ERROR\tRewrite input correctly.");
						return;
					}
					break;
				case "-p":
					try {
						port = Integer.parseInt(input[i + 1]);
						i += 1;
					} catch (Exception e) {
						System.out.println("ERROR\tMissing port number!");
						System.out.println("ERROR\tRewrite input correctly.");
						return;
					}
					break;
				case "-mx":
					if (queryFlag.equals("NS")) {
						System.out.println("ERROR\tOnly ONE of -mx or -ns flags allowed!");
						System.out.println("ERROR\tRewrite input correctly.");
						return;
					}
					queryFlag = "MX";
					break;
				case "-ns":
					if (queryFlag.equals("MX")) {
						System.out.println("ERROR\tOnly ONE of -mx or -ns flags allowed!");
						System.out.println("ERROR\tRewrite input correctly.");
						return;
					}
					queryFlag = "NS";
					break;

				default:
					if (input[i].charAt(0) == '@') {
						// Check a.b.c.d format of the address.
						int commas = 0;
						for (int j = 0; j < input[i].length(); j++) {
							if (input[i].charAt(j) == '.')
								commas += 1;
						}

						if (commas != 3)
							System.out.println("ERROR\t@a.b.c.d IP Adress format not respected!");
						serverFlag = true;
						serverIPString = input[i];
						int length = serverIPString.length();
						serverIPString = serverIPString.substring(1, length);
						String[] components = serverIPString.split("\\.");
						for (int j = 0; j < components.length; j++) {
							int ipVal = Integer.parseInt(components[j]);
							serverIP[j] = (byte) ipVal;
						}

					} else {
						nameFlag = true;
						name = input[i];
					}
					break;
			}
		}

		if ((serverFlag == true) && (nameFlag == true)) {
			// System.out.println("All good!");
		} else {
			if (!serverFlag)
				System.out.println("ERROR\tMissing server!");
			if (!nameFlag)
				System.out.println("ERROR\tMissing name!");
		}
	}
}