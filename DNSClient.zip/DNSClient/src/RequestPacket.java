
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.Random;

public class RequestPacket {
	String[] name;
	String queryFlag;
	byte[] requestPacket;

	public RequestPacket(String name, String queryFlag) {
		// System.out.println("name: " + name);
		this.name = name.split("\\.");
		this.queryFlag = queryFlag;
	}

	private byte[] genHeader() {
		ByteArrayOutputStream byteStreamHeader = new ByteArrayOutputStream();
		Random r = new Random();

		byte[] id = new byte[2];
		r.nextBytes(id);
		byte[] flags = { (byte) 0x01, (byte) 0x00 };
		byte[] qdCount = { (byte) 0x00, (byte) 0x01 };
		byte[] anCount = { (byte) 0x00, (byte) 0x00 };
		byte[] nsCount = { (byte) 0x00, (byte) 0x00 };
		byte[] arCount = { (byte) 0x00, (byte) 0x00 };

		byteStreamHeader.writeBytes(id);
		byteStreamHeader.writeBytes(flags);
		byteStreamHeader.writeBytes(qdCount);
		byteStreamHeader.writeBytes(anCount);
		byteStreamHeader.writeBytes(nsCount);
		byteStreamHeader.writeBytes(arCount);

		return byteStreamHeader.toByteArray();

		// byte[] header = Arrays.copyOf(id, 12);
		// Arrays.
	}

	private byte[] genQuestion() {
		ByteArrayOutputStream byteStreamQuestion = new ByteArrayOutputStream();
		for (String label : name) {

			int labelLength = label.length();
			byteStreamQuestion.write((byte) labelLength);
			byteStreamQuestion.writeBytes(genASCIIReps(label));

		}
		byteStreamQuestion.write((byte) 0);

		byte[] qType = new byte[2];
		qType[0] = (byte) 0x00;
		switch (queryFlag) {
			case "MX":
				qType[1] = (byte) 0x0f;
				break;
			case "NS":
				qType[1] = (byte) 0x02;
				break;
			default:
				qType[1] = (byte) 0x01;
				break;
		}
		byteStreamQuestion.writeBytes(qType);
		byte[] qClass = { (byte) 0x00, (byte) 0x01 };
		byteStreamQuestion.writeBytes(qClass);

		return byteStreamQuestion.toByteArray();
	}

	private byte[] genASCIIReps(String label) {
		char[] chars = label.toCharArray();
		byte[] reps = new byte[chars.length];
		for (int i = 0; i < chars.length; i++) {
			reps[i] = (byte) ((int) chars[i]);
		}
		return reps;
	}

	public byte[] genRequestPacket() {

		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		byteStream.writeBytes(genHeader());
		byteStream.writeBytes(genQuestion());

		return byteStream.toByteArray();

	}
}

// import java.nio.ByteBuffer;
// import java.util.Random;


// public class RequestPacket {

// 	private String domain;
// 	private String qt;
// 	public RequestPacket(String domain, String type){
// 		this.domain = domain;
// 		this.qt = type;
// 	}

// 	public byte[] getRequest(){
// 		int qNameLength = getQNameLength();
// 		ByteBuffer request = ByteBuffer.allocate(12 + 5 + qNameLength);
// 		request.put(createRequestHeader());
// 		request.put(createQuestionHeader(qNameLength));
//         return request.array();
// 	}

// 	private byte[] createRequestHeader(){
// 		ByteBuffer header = ByteBuffer.allocate(12);
// 		byte[] randomID = new byte[2]; 
// 		new Random().nextBytes(randomID);
// 		header.put(randomID);
// 		header.put((byte)0x01);
// 		header.put((byte)0x00);
// 		header.put((byte)0x00);
// 		header.put((byte)0x01);
		
// 		//lines 3, 4, and 5 will be all 0s, which is what we want
// 		return header.array();
// 	}
	
// 	private int getQNameLength(){
// 		int byteLength = 0;
// 		String[] items = domain.split("\\.");
// 		for(int i=0; i < items.length; i ++){
// 			// 1 byte length for the number value and then another for each character
// 			//www.mcgill.ca = 3, w, w, w, 6, m, c, g, i, l, l, 2, c, a = 14 byteLength
// 			byteLength += items[i].length() + 1;
// 		}
// 		return byteLength;
// 	}

// 	private byte[] createQuestionHeader(int qNameLength){
// 		ByteBuffer question = ByteBuffer.allocate(qNameLength+5);
		
// 		//first calculate how many bytes we need so we know the size of the array
// 		String[] items = domain.split("\\.");
// 		for(int i=0; i < items.length; i ++){
// 			question.put((byte) items[i].length());
// 			for (int j = 0; j < items[i].length(); j++){
// 				question.put((byte) ((int) items[i].charAt(j)));
				
// 			}
// 		}

// 		question.put((byte) 0x00);

// 		//Add Query Type
// 		question.put(hexStringToByteArray("000" + hexValueFromQueryType(qt)));
// 		question.put((byte) 0x00);
// 		//Add Query Class - always  0x0001 for internet addresses
// 		question.put((byte) 0x0001);

// 		return question.array();
// 	}
	
// 	private char hexValueFromQueryType(String type){
// 		if (type.equals("A")) {
// 			return '1';
// 		} else if (type.equals("NS")) {
// 			return '2';
// 		} else {
// 			return 'F';
// 		}
// 	}

// 	private static byte[] hexStringToByteArray(String s) {
// 		int len = s.length();
// 	    byte[] data = new byte[len / 2];
// 	    for (int i = 0; i < len; i += 2) {
// 	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
// 	                             + Character.digit(s.charAt(i+1), 16));
// 	    }
// 	    return data;
// 	}
// }
