public class App {
    public static void main(String[] args) throws Exception {
        // System.out.println("Hello, World!");
        // String[] tt = {"-ns", "@8.8.8.8", "mcgill.ca"};
        // String[] tt = {"-mx", "@8.8.8.8", "youtube.com"};
        String[][] tt = {
            // {"@8.8.8.8", "mcgill.ca"},
            // {"@8.8.8.8", "google.com"},
            // {"-ns", "@8.8.8.8", "mcgill.ca"},
            // {"-mx", "@8.8.8.8", "mcgill.ca"},
            // {"-mx", "@8.8.8.8", "youtube.com"},
            // {"-ns", "@8.8.8.8", "google.com"}
            
            // {"-ns", "@8.8.8.8", "facebook.com"},
            // {"-ns", "@8.8.8.8", "google.com"},
            // {"@8.8.8.8", "mcgill.ca"},
            {"-ns", "@8.8.8.8", "mcgill.ca"},
            // {"-mx", "@8.8.8.8", "mcgill.ca"}
        };
        
        for (String[] strings : tt) {

            System.out.println();
            DNSClient client = new DNSClient();
            client.DNSClientHandler(strings);
            System.out.println();
            // TimeUnit.MILLISECONDS.sleep(2000);
        }
    }
}
